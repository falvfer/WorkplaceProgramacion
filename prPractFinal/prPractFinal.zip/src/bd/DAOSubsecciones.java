package bd;

public class DAOSubsecciones {

}
